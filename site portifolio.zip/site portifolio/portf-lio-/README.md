# portf-lio-
Este repositório contém meu portfólio pessoal, desenvolvido para apresentar quem sou, minhas habilidades e os projetos que venho construindo ao longo da minha jornada em Engenharia de Software. O objetivo é compartilhar minha evolução como desenvolvedor e centralizar meus principais trabalhos.
